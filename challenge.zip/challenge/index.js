/**
* This javascript file will constitute the entry point of your solution.
*
* Edit it as you need.  It currently contains things that you might find helpful to get started.
*/

// This is not really required, but means that changes to index.html will cause a reload.
require('./site/index.html')
// Apply the styles in style.css to the page.
//require('./site/style.css')

// if you want to use es6, you can do something like
require('./es6/custom.css')
// here to load the myEs6code.js file, and it will be automatically transpiled.

// Change this to get detailed logging from the stomp library
global.DEBUG = false

const url = "ws://localhost:8011/stomp"
const client = Stomp.client(url)
client.debug = function(msg) {
	if (global.DEBUG) {
		console.info(msg)
	}
}


//To draw sparkline need an array of last changed bid rate changed.
const array_spark = [];

//This function accepts data from server and displays on client screen(Browser)
const connectCallback = function(x) 
{
	//this is for to accept the data from server
	client.subscribe("/fx/prices", function(d) {

	//to parse data into json format
	const jsondata = JSON.parse(d.body);

	//Declare an array of Currency Pairs 
	var newItem = jsondata.currencypairs;

	for(var i=0;i<newItem.length;i++)
	{
		const row = document.createElement('tr');  // create row node
		row.setAttribute("id", i); //assign id to each row
		row.setAttribute("data-name", newItem[i]); //set data attribute for a row
		const col = document.createElement('td');  // create column node for currencypair name
		col.setAttribute("id", newItem[i] ); //assign id to each column
		const col2 = document.createElement('td'); // create second column node bestBid
		col2.setAttribute("id", "bestBid"+i); //assign id to each column
		const col3 = document.createElement('td'); // create third column node bestAsk
		col3.setAttribute("id", "bestAsk"+i); //assign id to each column
		const col4 = document.createElement('td'); // create fourth column node openBid
		col4.setAttribute("id", "openBid"+i); //assign id to each column
		const col5 = document.createElement('td'); // create fifth column node openAsk
		col5.setAttribute("id", "openAsk"+i); //assign id to each column
		const col6 = document.createElement('td'); // create sixth column node lastChangeAsk
		col6.setAttribute("id", "lastChangeAsk"+i); //assign id to each column
		const col7 = document.createElement('td'); // create seventh column node lastChangeBid
		col7.setAttribute("id", "lastChangeBid"+i); //assign id to each column

		//append the columns to rows
		row.appendChild(col); // append first column to row(currencypair name)
		row.appendChild(col2); // append second column to row(bestBid)
		row.appendChild(col3); // append third column to row(bestAsk)
		row.appendChild(col4); // append fourth column to row(openBid)
		row.appendChild(col5); // append fifth column to row(openAsk)
		row.appendChild(col6); // append sixth column to row(lastChangeAsk)
		row.appendChild(col7); // append seventh column to row(lastChangeBid)
		col.innerHTML = newItem[i]; // put data in first column

		//Get Table body By it's Id attribute
		var table = document.getElementById("tbody"); // find table to append to

		//To append the row to table.
		if($('#tbody tr').length < 12)
		{
			table.appendChild(row); 
		}
	}

	//for showing updated values to table
	$('#tbody').find('tr').each(function(){
		var old_lastChangeBid=0;
		first_col = $(this).attr('data-name'); //to get the currencypair by its data attribute 

		//var jsondata.name = $(this).text();
		if(first_col == jsondata.name)
		{
			id = $(this).attr('id');
			$("#bestBid"+id).html(jsondata.bestBid); //change the values as per the data coming from server 
			$("#bestAsk"+id).html(jsondata.bestAsk);
			$("#openBid"+id).html(jsondata.openBid);
			$("#openAsk"+id).html(jsondata.openAsk);
			$("#lastChangeAsk"+id).html(jsondata.lastChangeAsk);
			$("#lastChangeBid"+id).html(jsondata.lastChangeBid);
		}
		else
		{
			old_lastChangeBid= jsondata.lastChangeBid;
		}

		var row = $(this).closest('tr');

		if (old_lastChangeBid > jsondata.lastChangeBid )
				row.prev().before(row);
		else
        	row.next().after(row);
	});

	//to draw a sparkline for each last bid changed.
	var bestbidrate = jsondata.bestBid; //calculate last best bid
	var bestaskrate = jsondata.bestAsk; //calculate last bestask
	var spark_form  = (bestbidrate + bestaskrate )/2; //to get midrate
	array_spark.push(spark_form); //push elements in an arry for draw sparkline from midrate
	//to draw a sparkline for each last bid changed.
	var sparkline = new Sparkline(document.getElementById("example-sparkline"));
	sparkline.draw(array_spark);

	});	 
};


client.connect({}, connectCallback, function(error) {
	alert(error.headers.message)
})


